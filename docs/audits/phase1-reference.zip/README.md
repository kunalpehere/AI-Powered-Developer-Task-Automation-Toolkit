# TaskMaster v2.0

**Advanced Task Scheduler & File Organizer**

A production-grade Python automation tool combining async task scheduling, intelligent file organization, duplicate detection, and a beautiful terminal interface.

## Features

### Task Scheduling
- ⏰ **Cron-like recurring tasks** (minutely, hourly, daily, weekly, monthly)
- 🔗 **Task dependencies** - tasks wait for prerequisites
- 🔄 **Auto-retry with exponential backoff**
- ⏱️ **Timeout handling**
- 🏷️ **Priority queue** (Low, Normal, High, Critical)
- 📊 **Persistent SQLite storage**
- 🔔 **Completion callbacks**

### File Organization
- 📁 **Smart sorting** by type, date, size, or custom rules
- 🔍 **Duplicate detection** using MD5 checksums
- 📝 **Template-based destinations** (`{type}`, `{date}`, `{name}`, `{ext}`)
- 🧪 **Dry-run mode** - preview before applying
- 📈 **Progress bars** for large operations
- 🗂️ **File indexing** for fast duplicate queries

### CLI Interface
- 🎨 **Rich terminal UI** with colors, tables, and panels
- 📺 **Live dashboard** with real-time updates
- 🧙 **Interactive wizards** for task creation and file organization
- 🖥️ **Command-line mode** for scripting

### Architecture
- ⚡ **Asyncio-based** scheduler with thread pool
- 🔌 **Plugin system** for extensibility
- 🗄️ **SQLite** persistence with indexes
- 🏗️ **Clean separation** of concerns (models, DB, scheduler, organizer, CLI)

## Installation

```bash
git clone <repo>
cd taskmaster
pip install -e .
# Or with optional dependencies:
pip install -e ".[full]"
```

## Quick Start

### Interactive Mode
```bash
taskmaster --interactive
# or
tm -i
```

### CLI Examples

**Add a scheduled task:**
```bash
tm task add --name "Daily Backup"    --command "rsync -a ~/docs /backup"    --schedule "2024-01-01 02:00"    --recurrence daily
```

**Organize Downloads folder:**
```bash
tm organize --source ~/Downloads --strategy type --dry-run
```

**Find and delete duplicates:**
```bash
tm duplicates --dir ~/Pictures --delete
```

**Start scheduler daemon:**
```bash
tm task start
```

## Project Structure

```
taskmaster/
├── __init__.py
├── __main__.py          # Entry point
├── models.py            # Data classes (Task, FileRule, FileOperation)
├── database.py          # SQLite persistence layer
├── scheduler.py         # Async task scheduler engine
├── organizer.py         # File organization engine
├── cli.py               # Rich terminal interface
├── plugins.py           # Plugin system
└── plugins/             # Custom plugins directory
```

## Advanced Concepts Demonstrated

1. **Asyncio & Threading**: Concurrent task execution with `asyncio` and `ThreadPoolExecutor`
2. **Context Managers**: Database connection pooling with `@contextmanager`
3. **Dataclasses**: Clean data models with `field()` defaults and serialization
4. **Decorators**: Task lifecycle management
5. **Abstract Base Classes**: Plugin architecture with `ABC`
6. **Type Hints**: Full typing with `Optional`, `List`, `Dict`, `Callable`
7. **Pathlib**: Modern path handling
8. **SQLite**: Indexed tables, transactions, connection management
9. **Error Handling**: Retry logic, exponential backoff, comprehensive logging
10. **CLI Design**: `argparse` subcommands, interactive prompts, progress bars

## License
MIT
