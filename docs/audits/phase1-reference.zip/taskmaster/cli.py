"""
TaskMaster - Rich CLI Interface
Beautiful terminal interface with live dashboards, tables, and progress bars.
"""
import asyncio
import argparse
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.layout import Layout
from rich.live import Live
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax
from rich.tree import Tree
from rich import box

from .models import Task, TaskStatus, TaskPriority, RecurrenceType, FileRule
from .database import Database
from .scheduler import TaskScheduler
from .organizer import FileOrganizer

console = Console()

class TaskMasterCLI:
    """Main CLI interface for TaskMaster."""

    def __init__(self):
        self.db = Database()
        self.scheduler = TaskScheduler(self.db)
        self.organizer = FileOrganizer(self.db)

    def print_banner(self):
        """Print application banner."""
        banner = """
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   ████████╗ █████╗ ███████╗██╗  ██╗███╗   ███╗ █████╗ ███████╗████████╗███████╗██████╗  ║
║   ╚══██╔══╝██╔══██╗██╔════╝██║ ██╔╝████╗ ████║██╔══██╗██╔════╝╚══██╔══╝██╔════╝██╔══██╗ ║
║      ██║   ███████║███████╗█████╔╝ ██╔████╔██║███████║███████╗   ██║   █████╗  ██████╔╝ ║
║      ██║   ██╔══██║╚════██║██╔═██╗ ██║╚██╔╝██║██╔══██║╚════██║   ██║   ██╔══╝  ██╔══██╗ ║
║      ██║   ██║  ██║███████║██║  ██╗██║ ╚═╝ ██║██║  ██║███████║   ██║   ███████╗██║  ██║ ║
║      ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝ ║
║                                                              ║
║         Advanced Task Scheduler & File Organizer v2.0        ║
╚══════════════════════════════════════════════════════════════╝
        """
        console.print(banner, style="bold cyan")

    def show_dashboard(self):
        """Show live dashboard with task and file stats."""
        stats = self.db.get_stats()

        layout = Layout()
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="main"),
            Layout(name="footer", size=3)
        )
        layout["main"].split_row(
            Layout(name="tasks"),
            Layout(name="files")
        )

        # Header
        header = Panel(
            f"[bold green]TaskMaster[/bold green] | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            style="bold white on blue"
        )
        layout["header"].update(header)

        # Tasks panel
        task_table = Table(title="Task Statistics", box=box.ROUNDED)
        task_table.add_column("Metric", style="cyan")
        task_table.add_column("Count", style="magenta")
        task_table.add_row("Total Tasks", str(stats["total_tasks"]))
        task_table.add_row("Pending", str(stats["pending_tasks"]), style="yellow")
        task_table.add_row("Completed", str(stats["completed_tasks"]), style="green")
        task_table.add_row("Failed", str(stats["failed_tasks"]), style="red")

        layout["tasks"].update(Panel(task_table, border_style="cyan"))

        # Files panel
        file_table = Table(title="File Operations", box=box.ROUNDED)
        file_table.add_column("Metric", style="cyan")
        file_table.add_column("Count", style="magenta")
        file_table.add_row("Operations", str(stats["file_operations"]))
        file_table.add_row("Indexed Files", str(stats["indexed_files"]))

        layout["files"].update(Panel(file_table, border_style="green"))

        # Footer
        footer = Panel(
            "[dim]Press Ctrl+C to exit dashboard[/dim]",
            style="dim"
        )
        layout["footer"].update(footer)

        console.print(layout)

    def show_tasks(self, status_filter: Optional[str] = None):
        """Display tasks in a formatted table."""
        tasks = self.db.get_all_tasks()

        if status_filter:
            tasks = [t for t in tasks if t["status"] == status_filter.upper()]

        if not tasks:
            console.print("[yellow]No tasks found.[/yellow]")
            return

        table = Table(
            title=f"Tasks ({len(tasks)} total)",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold magenta"
        )

        table.add_column("ID", style="dim", width=8)
        table.add_column("Name", style="cyan", min_width=20)
        table.add_column("Status", width=12)
        table.add_column("Priority", width=8)
        table.add_column("Schedule", width=16)
        table.add_column("Runs", width=6)
        table.add_column("Next Run", width=16)

        status_colors = {
            "PENDING": "yellow",
            "RUNNING": "blue",
            "COMPLETED": "green",
            "FAILED": "red",
            "CANCELLED": "dim",
            "PAUSED": "orange3"
        }

        for task in tasks:
            status_color = status_colors.get(task["status"], "white")
            next_run = task["next_run"] or "N/A"
            if next_run != "N/A":
                next_run = next_run[:16]

            table.add_row(
                task["id"],
                task["name"][:30],
                f"[{status_color}]{task['status']}[/{status_color}]",
                str(task["priority"]),
                task["schedule_time"][:16],
                str(task["run_count"]),
                next_run
            )

        console.print(table)

    def add_task_interactive(self):
        """Interactive task creation wizard."""
        console.print("
[bold cyan]Create New Task[/bold cyan]
")

        name = Prompt.ask("Task name")

        console.print("
[bold]Recurrence Options:[/bold]")
        console.print("1. One-time")
        console.print("2. Minutely")
        console.print("3. Hourly")
        console.print("4. Daily")
        console.print("5. Weekly")

        rec_choice = Prompt.ask("Choose recurrence", choices=["1","2","3","4","5"], default="1")
        recurrence_map = {
            "1": RecurrenceType.ONCE,
            "2": RecurrenceType.MINUTELY,
            "3": RecurrenceType.HOURLY,
            "4": RecurrenceType.DAILY,
            "5": RecurrenceType.WEEKLY,
        }
        recurrence = recurrence_map[rec_choice]

        interval = None
        if recurrence == RecurrenceType.MINUTELY:
            interval = int(Prompt.ask("Interval (minutes)", default="5"))

        # Schedule time
        if recurrence == RecurrenceType.ONCE:
            schedule_str = Prompt.ask("Schedule time (YYYY-MM-DD HH:MM)", 
                                    default=datetime.now().strftime("%Y-%m-%d %H:%M"))
            schedule_time = datetime.strptime(schedule_str, "%Y-%m-%d %H:%M")
        else:
            schedule_time = datetime.now()

        # Priority
        console.print("
[bold]Priority:[/bold]")
        console.print("1. Low")
        console.print("2. Normal")
        console.print("3. High")
        console.print("4. Critical")

        pri_choice = Prompt.ask("Choose priority", choices=["1","2","3","4"], default="2")
        priority_map = {
            "1": TaskPriority.LOW,
            "2": TaskPriority.NORMAL,
            "3": TaskPriority.HIGH,
            "4": TaskPriority.CRITICAL,
        }
        priority = priority_map[pri_choice]

        # Command type
        console.print("
[bold]Command Type:[/bold]")
        console.print("1. Shell command")
        console.print("2. Python function")
        console.print("3. File organization")

        cmd_choice = Prompt.ask("Choose type", choices=["1","2","3"], default="1")

        if cmd_choice == "1":
            command_str = Prompt.ask("Enter shell command")
            import subprocess
            def command():
                result = subprocess.run(command_str, shell=True, capture_output=True, text=True)
                return result.stdout

        elif cmd_choice == "2":
            console.print("[yellow]Define a Python function (lambda or simple):[/yellow]")
            func_str = Prompt.ask("Function", default="lambda: print('Hello from task!')")
            command = eval(func_str)

        else:  # File organization
            source_dir = Prompt.ask("Source directory")
            dest_template = Prompt.ask("Destination template", default="organized/{type}/{name}.{ext}")

            def command():
                rule = FileRule(
                    name="auto_organize",
                    source_pattern="*",
                    destination_template=dest_template,
                    action="move"
                )
                self.organizer.add_rule(rule)
                results = self.organizer.organize_directory(Path(source_dir))
                return self.organizer.generate_report(results)

        # Create task
        task = Task(
            name=name,
            command=command,
            schedule_time=schedule_time,
            recurrence=recurrence,
            interval_minutes=interval,
            priority=priority
        )

        task_id = self.scheduler.register_task(task)
        console.print(f"
[green]✓ Task created with ID: {task_id}[/green]")

        return task_id

    def organize_files_interactive(self):
        """Interactive file organization wizard."""
        console.print("
[bold cyan]File Organization Wizard[/bold cyan]
")

        source_dir = Prompt.ask("Source directory", default=str(Path.home() / "Downloads"))
        source_path = Path(source_dir)

        if not source_path.exists():
            console.print(f"[red]Directory not found: {source_dir}[/red]")
            return

        # Show preview
        files = self.organizer.scan_directory(source_path)
        console.print(f"
Found [bold]{len(files)}[/bold] files")

        # Organization strategy
        console.print("
[bold]Organization Strategy:[/bold]")
        console.print("1. By file type (images, documents, etc.)")
        console.print("2. By date (YYYY/MM)")
        console.print("3. By size (small/medium/large)")
        console.print("4. Custom rules")

        strategy = Prompt.ask("Choose strategy", choices=["1","2","3","4"], default="1")

        templates = {
            "1": "organized/{type}/{name}.{ext}",
            "2": "organized/{year}/{month}/{name}.{ext}",
            "3": "organized/{size_category}/{name}.{ext}",
        }

        if strategy == "4":
            template = Prompt.ask("Enter template", default="organized/{type}/{name}.{ext}")
        else:
            template = templates[strategy]
            if strategy == "3":
                # Add size-based condition
                def size_condition(path: Path):
                    size = path.stat().st_size
                    if size < 1024 * 1024:
                        return "small"
                    elif size < 100 * 1024 * 1024:
                        return "medium"
                    else:
                        return "large"

                # Override template for size
                template = "organized/{size_category}/{name}.{ext}"

        # Dry run option
        dry_run = Confirm.ask("Perform dry run first?", default=True)

        if dry_run:
            self.organizer.dry_run = True
            console.print("
[yellow]--- DRY RUN MODE ---[/yellow]")

        # Add default rule
        rule = FileRule(
            name="interactive_organize",
            source_pattern="*",
            destination_template=template,
            action="move"
        )
        self.organizer.add_rule(rule)

        # Execute
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console
        ) as progress:
            task_progress = progress.add_task("[cyan]Organizing files...", total=len(files))

            results = self.organizer.organize_directory(source_path)

            for i, _ in enumerate(results):
                progress.update(task_progress, advance=1)
                time.sleep(0.01)  # Small delay for visual effect

        # Report
        report = self.organizer.generate_report(results)

        console.print("
[bold green]Organization Complete![/bold green]")
        console.print(f"Total files: {report['total_files']}")
        console.print(f"Successful: {report['successful']}")
        console.print(f"Failed: {report['failed']}")
        console.print(f"Total size: {report['total_size_mb']} MB")

        if dry_run and Confirm.ask("Apply changes for real?", default=False):
            self.organizer.dry_run = False
            console.print("
[yellow]Applying changes...[/yellow]")
            results = self.organizer.organize_directory(source_path)
            report = self.organizer.generate_report(results)
            console.print(f"[green]Done! {report['successful']} files organized.[/green]")

    def find_duplicates_interactive(self):
        """Interactive duplicate file finder."""
        console.print("
[bold cyan]Duplicate File Finder[/bold cyan]
")

        directory = Prompt.ask("Directory to scan", default=str(Path.home()))
        dir_path = Path(directory)

        if not dir_path.exists():
            console.print(f"[red]Directory not found: {directory}[/red]")
            return

        fast_mode = Confirm.ask("Use fast mode? (quicker, less accurate)", default=True)

        console.print("
[yellow]Scanning for duplicates...[/yellow]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            progress.add_task("[cyan]Computing checksums...", total=None)
            duplicates = self.organizer.find_duplicates(dir_path, fast_mode=fast_mode)

        if not duplicates:
            console.print("
[green]No duplicates found![/green]")
            return

        console.print(f"
[bold]Found {len(duplicates)} duplicate groups[/bold]
")

        for checksum, paths in list(duplicates.items())[:10]:  # Show first 10
            size = paths[0].stat().st_size
            tree = Tree(f"[bold]{checksum[:16]}...[/bold] ({size / 1024:.1f} KB)")
            for path in paths:
                tree.add(f"[dim]{path}[/dim]")
            console.print(tree)
            console.print()

        if len(duplicates) > 10:
            console.print(f"[dim]... and {len(duplicates) - 10} more groups[/dim]")

        if Confirm.ask("Delete duplicates (keep first occurrence)?", default=False):
            deleted = 0
            freed = 0

            for checksum, paths in duplicates.items():
                for path in paths[1:]:  # Keep first, delete rest
                    try:
                        size = path.stat().st_size
                        path.unlink()
                        deleted += 1
                        freed += size
                    except Exception as e:
                        console.print(f"[red]Error deleting {path}: {e}[/red]")

            console.print(f"
[green]Deleted {deleted} duplicates, freed {freed / (1024*1024):.2f} MB[/green]")

    def run_interactive(self):
        """Run interactive mode."""
        self.print_banner()

        while True:
            console.print("
[bold cyan]Main Menu[/bold cyan]")
            console.print("1. Dashboard")
            console.print("2. View Tasks")
            console.print("3. Add Task")
            console.print("4. Start Scheduler")
            console.print("5. Organize Files")
            console.print("6. Find Duplicates")
            console.print("7. View Statistics")
            console.print("8. Exit")

            choice = Prompt.ask("
Select option", choices=["1","2","3","4","5","6","7","8"])

            if choice == "1":
                self.show_dashboard()

            elif choice == "2":
                self.show_tasks()

            elif choice == "3":
                self.add_task_interactive()

            elif choice == "4":
                console.print("
[yellow]Starting scheduler... Press Ctrl+C to stop[/yellow]")
                try:
                    asyncio.run(self._run_scheduler_live())
                except KeyboardInterrupt:
                    console.print("
[red]Scheduler stopped.[/red]")

            elif choice == "5":
                self.organize_files_interactive()

            elif choice == "6":
                self.find_duplicates_interactive()

            elif choice == "7":
                stats = self.db.get_stats()
                for key, value in stats.items():
                    console.print(f"[cyan]{key}:[/cyan] {value}")

            elif choice == "8":
                console.print("
[green]Goodbye![/green]")
                break

    async def _run_scheduler_live(self):
        """Run scheduler with live status updates."""
        await self.scheduler.start()

        try:
            while True:
                console.clear()
                self.show_dashboard()
                await asyncio.sleep(2)
        except asyncio.CancelledError:
            pass
        finally:
            await self.scheduler.stop()

    def run_cli(self, args: Optional[List[str]] = None):
        """Run with command-line arguments."""
        parser = argparse.ArgumentParser(
            description="TaskMaster - Advanced Task Scheduler & File Organizer",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  %(prog)s --interactive              Launch interactive mode
  %(prog)s task add --name "Backup" --command "rsync -a ~/docs /backup" --schedule "2024-01-01 00:00"
  %(prog)s task list
  %(prog)s organize --source ~/Downloads --strategy type
  %(prog)s duplicates --dir ~/Pictures --delete
            """
        )

        parser.add_argument("--interactive", "-i", action="store_true", 
                           help="Launch interactive mode")

        subparsers = parser.add_subparsers(dest="command", help="Available commands")

        # Task commands
        task_parser = subparsers.add_parser("task", help="Task management")
        task_sub = task_parser.add_subparsers(dest="task_cmd")

        task_add = task_sub.add_parser("add", help="Add a new task")
        task_add.add_argument("--name", required=True)
        task_add.add_argument("--command", required=True)
        task_add.add_argument("--schedule", required=True, help="YYYY-MM-DD HH:MM")
        task_add.add_argument("--recurrence", choices=["once","minutely","hourly","daily","weekly"],
                             default="once")
        task_add.add_argument("--priority", type=int, choices=[1,2,3,4], default=2)

        task_sub.add_parser("list", help="List all tasks")
        task_sub.add_parser("start", help="Start scheduler")

        # Organize commands
        org_parser = subparsers.add_parser("organize", help="Organize files")
        org_parser.add_argument("--source", required=True)
        org_parser.add_argument("--strategy", choices=["type","date","size"], default="type")
        org_parser.add_argument("--dry-run", action="store_true")

        # Duplicate commands
        dup_parser = subparsers.add_parser("duplicates", help="Find duplicates")
        dup_parser.add_argument("--dir", required=True)
        dup_parser.add_argument("--delete", action="store_true")

        parsed = parser.parse_args(args)

        if parsed.interactive or not parsed.command:
            self.run_interactive()
            return

        if parsed.command == "task":
            if parsed.task_cmd == "add":
                from .models import Task
                schedule_time = datetime.strptime(parsed.schedule, "%Y-%m-%d %H:%M")

                import subprocess
                def cmd():
                    result = subprocess.run(parsed.command, shell=True, capture_output=True, text=True)
                    return result.stdout

                task = Task(
                    name=parsed.name,
                    command=cmd,
                    schedule_time=schedule_time,
                    recurrence=RecurrenceType(parsed.recurrence),
                    priority=TaskPriority(parsed.priority)
                )
                task_id = self.scheduler.register_task(task)
                console.print(f"[green]Task created: {task_id}[/green]")

            elif parsed.task_cmd == "list":
                self.show_tasks()

            elif parsed.task_cmd == "start":
                console.print("[yellow]Starting scheduler...[/yellow]")
                try:
                    asyncio.run(self._run_scheduler_live())
                except KeyboardInterrupt:
                    console.print("[red]Stopped.[/red]")

        elif parsed.command == "organize":
            self.organizer.dry_run = parsed.dry_run
            source = Path(parsed.source)

            templates = {
                "type": "organized/{type}/{name}.{ext}",
                "date": "organized/{year}/{month}/{name}.{ext}",
                "size": "organized/{size_category}/{name}.{ext}",
            }

            rule = FileRule(
                name="cli_organize",
                source_pattern="*",
                destination_template=templates[parsed.strategy],
                action="move"
            )
            self.organizer.add_rule(rule)

            results = self.organizer.organize_directory(source)
            report = self.organizer.generate_report(results)

            console.print(f"[green]Organized {report['successful']} files[/green]")
            if report['failed'] > 0:
                console.print(f"[red]Failed: {report['failed']}[/red]")

        elif parsed.command == "duplicates":
            dir_path = Path(parsed.dir)
            duplicates = self.organizer.find_duplicates(dir_path)

            console.print(f"[cyan]Found {len(duplicates)} duplicate groups[/cyan]")

            if parsed.delete:
                deleted = 0
                for checksum, paths in duplicates.items():
                    for path in paths[1:]:
                        path.unlink()
                        deleted += 1
                console.print(f"[green]Deleted {deleted} duplicates[/green]")

def main():
    """Entry point."""
    cli = TaskMasterCLI()
    cli.run_cli()

if __name__ == "__main__":
    main()
