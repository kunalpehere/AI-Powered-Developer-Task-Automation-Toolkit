#!/usr/bin/env python3
"""
TaskMaster Demo Script
Demonstrates all major features without running the full scheduler.
"""
import sys
sys.path.insert(0, "/mnt/agents/output")

from pathlib import Path
from datetime import datetime, timedelta
from taskmaster.models import Task, TaskStatus, TaskPriority, RecurrenceType, FileRule
from taskmaster.database import Database
from taskmaster.organizer import FileOrganizer

print("=" * 60)
print("TaskMaster v2.0 - Feature Demo")
print("=" * 60)

# 1. Database Demo
print("
📊 DATABASE LAYER")
print("-" * 40)
db = Database(":memory:")  # In-memory for demo

# 2. Task Model Demo
print("
📋 TASK MODELS")
print("-" * 40)

def sample_task_command():
    return "Task executed successfully!"

task = Task(
    name="Daily Report Generation",
    command=sample_task_command,
    schedule_time=datetime.now() + timedelta(hours=1),
    recurrence=RecurrenceType.DAILY,
    priority=TaskPriority.HIGH,
    tags={"reports", "automation"},
    max_retries=3,
    timeout_seconds=300
)

print(f"Task ID: {task.id}")
print(f"Name: {task.name}")
print(f"Status: {task.status.name}")
print(f"Priority: {task.priority.name}")
print(f"Recurrence: {task.recurrence.value}")
print(f"Next run: {task.calculate_next_run()}")
print(f"Tags: {task.tags}")

# Serialize to dict
print(f"
Serialized (first 200 chars):")
print(str(task.to_dict())[:200] + "...")

# 3. Database Operations
print("
🗄️  DATABASE OPERATIONS")
print("-" * 40)

db.save_task(task)
print(f"✓ Saved task to database")

retrieved = db.get_task(task.id)
print(f"✓ Retrieved task: {retrieved['name']}")

stats = db.get_stats()
print(f"✓ Database stats: {stats}")

# 4. File Organizer Demo
print("
📁 FILE ORGANIZER")
print("-" * 40)

organizer = FileOrganizer(db, dry_run=True)

# Show file categories
print("File Categories:")
for cat, exts in organizer.CATEGORIES.items():
    print(f"  {cat:12s}: {', '.join(list(exts)[:5])}{'...' if len(exts) > 5 else ''}")

# Template demo
file_info = {
    "stem": "vacation_photo",
    "extension": ".jpg",
    "category": "images",
    "mime_type": "image/jpeg"
}
template = "organized/{type}/{year}/{month}/{name}.{ext}"
result = organizer.apply_template(template, file_info)
print(f"
Template: {template}")
print(f"Result:   {result}")

# 5. File Rule Demo
print("
📜 FILE RULES")
print("-" * 40)

rule = FileRule(
    name="sort_photos",
    source_pattern="*.jpg",
    destination_template="photos/{year}/{month}/{name}.{ext}",
    action="move",
    priority=10
)
print(f"Rule: {rule.name}")
print(f"Pattern: {rule.source_pattern}")
print(f"Template: {rule.destination_template}")
print(f"Action: {rule.action}")

# 6. Plugin System Demo
print("
🔌 PLUGIN SYSTEM")
print("-" * 40)

from taskmaster.plugins import PluginManager, ImageProcessorPlugin

pm = PluginManager()

# Register built-in plugins
pm.register_file_plugin(ImageProcessorPlugin())

plugins = pm.list_plugins()
print(f"Registered plugins: {plugins}")

# 7. Advanced Features Summary
print("
🚀 ADVANCED FEATURES")
print("-" * 40)

features = [
    ("Async Scheduler", "asyncio + ThreadPoolExecutor for concurrent tasks"),
    ("Priority Queue", "Tasks ordered by priority with asyncio.PriorityQueue"),
    ("Dependency Graph", "Tasks wait for prerequisites before execution"),
    ("Exponential Backoff", "Auto-retry: 2^attempt seconds (max 5 min)"),
    ("Timeout Handling", "Per-task timeout with asyncio.wait_for"),
    ("SQLite Persistence", "Indexed tables, transactions, connection pooling"),
    ("Checksum Deduplication", "MD5 hashing for duplicate detection"),
    ("Template Engine", "Dynamic paths with {type}, {date}, {name}, {ext}"),
    ("Plugin Architecture", "ABC-based extensible plugin system"),
    ("Rich CLI", "Live dashboards, progress bars, interactive wizards"),
]

for name, desc in features:
    print(f"  ✓ {name:20s} - {desc}")

print("
" + "=" * 60)
print("Demo complete! Run 'taskmaster --interactive' to try it live.")
print("=" * 60)
