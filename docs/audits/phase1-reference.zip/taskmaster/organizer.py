"""
TaskMaster - Advanced File Organizer
Smart file organization with duplicate detection, content analysis, and rules engine.
"""
import os
import hashlib
import shutil
import mimetypes
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Callable, Set, Tuple
from concurrent.futures import ThreadPoolExecutor
import asyncio

from .models import FileRule, FileOperation
from .database import Database

class FileOrganizer:
    """Advanced file organizer with rule-based processing and duplicate detection."""

    # File type categories
    CATEGORIES = {
        "images": {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".ico"},
        "videos": {".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm"},
        "audio": {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"},
        "documents": {".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".xls", ".xlsx", ".ppt", ".pptx"},
        "code": {".py", ".js", ".html", ".css", ".java", ".cpp", ".c", ".h", ".go", ".rs", ".ts"},
        "archives": {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"},
        "data": {".json", ".xml", ".csv", ".yaml", ".yml", ".sql", ".db"},
        "executables": {".exe", ".msi", ".dmg", ".pkg", ".deb", ".rpm", ".appimage"},
    }

    def __init__(self, db: Database, dry_run: bool = False):
        self.db = db
        self.dry_run = dry_run
        self.rules: List[FileRule] = []
        self._executor = ThreadPoolExecutor(max_workers=8)

    def add_rule(self, rule: FileRule) -> None:
        """Add an organization rule."""
        self.rules.append(rule)
        self.rules.sort(key=lambda r: r.priority, reverse=True)

    def get_file_category(self, path: Path) -> str:
        """Determine file category based on extension."""
        ext = path.suffix.lower()
        for category, extensions in self.CATEGORIES.items():
            if ext in extensions:
                return category
        return "misc"

    def calculate_checksum(self, path: Path, algorithm: str = "md5", 
                          chunk_size: int = 8192) -> str:
        """Calculate file checksum for duplicate detection."""
        hash_obj = hashlib.new(algorithm)
        with open(path, "rb") as f:
            while chunk := f.read(chunk_size):
                hash_obj.update(chunk)
        return hash_obj.hexdigest()

    def get_file_info(self, path: Path) -> Dict[str, any]:
        """Get comprehensive file information."""
        stat = path.stat()
        return {
            "path": path,
            "name": path.name,
            "stem": path.stem,
            "extension": path.suffix.lower(),
            "size": stat.st_size,
            "modified": datetime.fromtimestamp(stat.st_mtime),
            "created": datetime.fromtimestamp(stat.st_ctime),
            "category": self.get_file_category(path),
            "mime_type": mimetypes.guess_type(str(path))[0] or "unknown",
        }

    def scan_directory(self, directory: Path, recursive: bool = True,
                      pattern: str = "*") -> List[Path]:
        """Scan directory for files matching pattern."""
        files = []
        directory = Path(directory)

        if recursive:
            for path in directory.rglob(pattern):
                if path.is_file():
                    files.append(path)
        else:
            for path in directory.glob(pattern):
                if path.is_file():
                    files.append(path)

        return files

    def find_duplicates(self, directory: Path, recursive: bool = True,
                       fast_mode: bool = True) -> Dict[str, List[Path]]:
        """Find duplicate files using checksum comparison."""
        files = self.scan_directory(directory, recursive)
        checksum_map: Dict[str, List[Path]] = {}

        def process_file(path: Path) -> Optional[Tuple[str, Path]]:
            try:
                if fast_mode:
                    # Quick check: size + first 1KB hash
                    stat = path.stat()
                    with open(path, "rb") as f:
                        header = f.read(1024)
                    quick_hash = hashlib.md5(
                        f"{stat.st_size}:{header}".encode()
                    ).hexdigest()
                    return (quick_hash, path)
                else:
                    return (self.calculate_checksum(path), path)
            except Exception:
                return None

        # Process in parallel
        futures = [self._executor.submit(process_file, f) for f in files]
        for future in futures:
            result = future.result()
            if result:
                checksum, path = result
                if checksum not in checksum_map:
                    checksum_map[checksum] = []
                checksum_map[checksum].append(path)

        # Filter to only duplicates
        duplicates = {k: v for k, v in checksum_map.items() if len(v) > 1}

        # Index in database
        for checksum, paths in duplicates.items():
            for path in paths:
                self.db.index_file(path, checksum, path.stat().st_size)

        return duplicates

    def apply_template(self, template: str, file_info: Dict[str, any]) -> Path:
        """Apply destination template with variable substitution."""
        now = datetime.now()

        replacements = {
            "{name}": file_info["stem"],
            "{ext}": file_info["extension"].lstrip("."),
            "{date}": now.strftime("%Y-%m-%d"),
            "{year}": now.strftime("%Y"),
            "{month}": now.strftime("%m"),
            "{day}": now.strftime("%d"),
            "{type}": file_info["category"],
            "{mime}": file_info["mime_type"].replace("/", "_"),
        }

        result = template
        for key, value in replacements.items():
            result = result.replace(key, value)

        return Path(result)

    def organize_file(self, source: Path, rule: FileRule) -> FileOperation:
        """Organize a single file according to a rule."""
        file_info = self.get_file_info(source)
        destination = self.apply_template(rule.destination_template, file_info)

        op = FileOperation(
            source=source,
            destination=destination,
            operation=rule.action,
            size_bytes=file_info["size"],
        )

        # Check custom condition
        if rule.condition and not rule.condition(source):
            op.status = "skipped"
            op.error = "Condition not met"
            self.db.log_file_operation(op)
            return op

        try:
            if self.dry_run:
                op.status = "dry_run"
                print(f"[DRY RUN] Would {rule.action} {source} -> {destination}")
            else:
                # Ensure destination directory exists
                destination.parent.mkdir(parents=True, exist_ok=True)

                if rule.action == "move":
                    shutil.move(str(source), str(destination))
                elif rule.action == "copy":
                    shutil.copy2(str(source), str(destination))
                elif rule.action == "rename":
                    source.rename(destination)
                elif rule.action == "delete":
                    source.unlink()

                op.status = "success"
                op.checksum = self.calculate_checksum(destination) if destination.exists() else None

                # Index the new file
                if destination.exists():
                    self.db.index_file(destination, op.checksum or "", file_info["size"])

        except Exception as e:
            op.status = "failed"
            op.error = str(e)

        self.db.log_file_operation(op)
        return op

    def organize_directory(self, source_dir: Path, 
                          recursive: bool = True) -> List[FileOperation]:
        """Organize all files in a directory according to rules."""
        files = self.scan_directory(source_dir, recursive)
        results = []

        for file_path in files:
            # Find matching rule
            matched = False
            for rule in self.rules:
                if not rule.enabled:
                    continue

                # Check if file matches rule pattern
                import fnmatch
                if fnmatch.fnmatch(file_path.name, rule.source_pattern):
                    op = self.organize_file(file_path, rule)
                    results.append(op)
                    matched = True
                    break

            if not matched:
                # Default: organize by type
                file_info = self.get_file_info(file_path)
                default_rule = FileRule(
                    name="default_type_sort",
                    source_pattern="*",
                    destination_template=f"organized/{{type}}/{{name}}.{{ext}}",
                    action="move"
                )
                op = self.organize_file(file_path, default_rule)
                results.append(op)

        return results

    def clean_empty_directories(self, directory: Path, 
                                recursive: bool = True) -> List[Path]:
        """Remove empty directories."""
        removed = []
        directory = Path(directory)

        if recursive:
            # Process from deepest to shallowest
            for path in sorted(directory.rglob("*"), key=lambda p: len(p.parts), reverse=True):
                if path.is_dir() and not any(path.iterdir()):
                    try:
                        path.rmdir()
                        removed.append(path)
                    except Exception:
                        pass

        return removed

    def generate_report(self, operations: List[FileOperation]) -> Dict[str, any]:
        """Generate summary report of operations."""
        total = len(operations)
        successful = sum(1 for op in operations if op.status == "success")
        failed = sum(1 for op in operations if op.status == "failed")
        skipped = sum(1 for op in operations if op.status == "skipped")
        dry_run = sum(1 for op in operations if op.status == "dry_run")

        total_size = sum(op.size_bytes for op in operations if op.status in ("success", "dry_run"))

        return {
            "total_files": total,
            "successful": successful,
            "failed": failed,
            "skipped": skipped,
            "dry_run": dry_run,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "timestamp": datetime.now().isoformat(),
        }
