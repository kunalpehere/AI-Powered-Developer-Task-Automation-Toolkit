"""
TaskMaster - Setup Configuration
"""
from setuptools import setup, find_packages

setup(
    name="taskmaster",
    version="2.0.0",
    description="Advanced Task Scheduler & File Organizer",
    author="Your Name",
    packages=find_packages(),
    install_requires=[
        "rich>=13.0.0",
    ],
    extras_require={
        "images": ["Pillow>=9.0.0"],
        "pdf": ["PyPDF2>=3.0.0"],
        "full": ["Pillow>=9.0.0", "PyPDF2>=3.0.0"],
    },
    entry_points={
        "console_scripts": [
            "taskmaster=taskmaster.cli:main",
            "tm=taskmaster.cli:main",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
