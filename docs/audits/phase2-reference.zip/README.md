# TaskMaster — Phase 1 baseline

A Python CLI for file organization and full-content duplicate reporting. Phase 1
repairs the inherited prototype's startup, packaging, dispatch, and critical file
safety defects. Developer-project inspection and validated workflows arrive in
later phases; this is not a production release.

## Install and test

Python 3.12 or newer is required; this phase is validated on Python 3.12.4 on
Windows. Run these PowerShell commands from the repository root, where
`pyproject.toml` lives:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m taskmaster --help
.\.venv\Scripts\taskmaster.exe --help
.\.venv\Scripts\tm.exe --help
```

On Linux/macOS the corresponding executables are `.venv/bin/python`,
`.venv/bin/taskmaster`, and `.venv/bin/tm`; those platforms are not yet validated.
Installing without `[dev]` installs only the runtime dependency, Rich. No API
keys, services, Pillow, or PDF packages are needed. Project metadata declares
supported dependency ranges; a full reproducible dependency lock is deferred.

If a managed Windows host rejects its default temporary directory, set `TEMP`
and `TMP` to an existing writable directory before creating the environment or
installing. Do not add administrator privileges just to install this project.

## Try the disposable demo

```powershell
.\.venv\Scripts\python.exe -m taskmaster.demo --directory .
```

The demo creates its own temporary child directory, previews copies, reports one
SHA-256 duplicate group, and removes its fixtures. It does not run the scheduler
or modify existing files. Run it as a module rather than as a script path.

## File commands

Use a disposable folder containing only selected artifacts for now. Do not sort an
entire source tree: moving files by extension can break a project. The inherited
organizer still scans recursively, uses the first matching rule, and writes
outputs under `organized/` relative to the current working directory.

```powershell
.\.venv\Scripts\taskmaster.exe organize --source .\sample-artifacts --strategy type --dry-run
.\.venv\Scripts\taskmaster.exe organize --source .\sample-artifacts --strategy type
.\.venv\Scripts\taskmaster.exe duplicates --dir .\sample-artifacts
```

- `type` and `date` organization are available. Date means the current date,
  not a file's modification date. Size sorting returns an actionable error until
  its implementation in Phase 3.
- Duplicate reports hash every file completely using SHA-256 and list every
  member of each matching group. Legacy Python `fast_mode=True` also hashes full
  contents. Read failures abort the scan with an error instead of silently
  reporting an incomplete result. Size-based candidate optimization is deferred.
- Automatic duplicate deletion is disabled in both CLI and interactive modes.
  `duplicates --delete` exits with a usage error and deletes nothing.
- Existing destination files, directories, and dangling symlinks are rejected.
  Exclusive destination creation protects against a file appearing between the
  initial conflict check and creation. Copy, move, and rename preserve existing
  destinations; move/rename currently copy to a new file and then unlink source.
- Unknown rule actions and nonexistent/non-directory sources fail with useful
  messages. Per-file failures are shown and cause CLI exit code 1. Argument errors
  use exit code 2; successful commands use 0.
- `--help` and argument-validation errors do not create a database. Other commands
  create/use `taskmaster.db` in the current working directory.

## Limits carried into later phases

Preview preserves source files but still writes history, and duplicate scans
still update the SQLite index. Preview/apply separation belongs to Phase 2.
Destination-root boundaries, parent symlinks/junctions, concurrent source changes,
rollback, and atomic filesystem-plus-history guarantees are not established.
A failed copy or metadata update may leave a partial/new destination; a failed
source unlink can leave both files. A history/index failure after a file change
can still report failure after the change happened. Review results before retrying.

The inherited `task add`, `task list`, `task start`, and interactive menu remain
available for experimentation. **Scheduler persistence/restoration, due times,
retries, dependencies, timeouts, and shutdown are unreliable or unverified.** A
saved task record does not include its command, so a later `task start` cannot
restore it. Task-add dispatch is fixed; that does not make scheduling reliable.
Interactive Python expression evaluation is disabled. Python callers may supply
callables directly; shell tasks raise on nonzero subprocess exit status.

The plugin import collision is resolved: `from taskmaster.plugins import
PluginManager` works. Explicit registration is tested; dynamic discovery and
image/PDF execution remain deferred and unverified. Discovery imports arbitrary
Python, so do not load untrusted plugins. Optional image/PDF dependencies and old
installation extras are not part of this baseline.

## Project status and provenance

See [development plan](DEVELOPMENT_PLAN.md),
[Phase 0 evidence](docs/audits/PHASE_0_AUDIT.md), and
[Phase 1 implementation record](docs/PHASE_1.md).
The original 13-file source/README snapshot and pre-change plan are preserved in
[the baseline archive](docs/audits/phase1-reference.zip). Phase 0 results remain
historical evidence; its defect collector is not the current regression suite.

This work derives from the supplied TaskMaster snapshot. Its upstream URL,
revision, copyright holder, and actual license notices remain unresolved. The
original README said MIT, but no LICENSE was supplied. No new licensing claim
is made; resolve provenance and retain required notices before distributing
inherited code. See [component attribution](ATTRIBUTION.md).
