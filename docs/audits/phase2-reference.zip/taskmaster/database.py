"""
TaskMaster - Database Layer
Handles persistence for tasks, file operations, and configuration.
"""
import sqlite3
import json
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any
from contextlib import contextmanager

from .models import Task, FileOperation, TaskStatus, RecurrenceType, TaskPriority

class Database:
    """SQLite database manager with connection pooling."""

    def __init__(self, db_path: str = "taskmaster.db"):
        self.db_path = db_path
        self._init_db()

    @contextmanager
    def _connection(self):
        """Context manager for database connections."""
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

    def _init_db(self):
        """Initialize database schema."""
        with self._connection() as conn:
            # Tasks table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    schedule_time TEXT NOT NULL,
                    recurrence TEXT DEFAULT 'once',
                    interval_minutes INTEGER,
                    priority INTEGER DEFAULT 2,
                    dependencies TEXT DEFAULT '[]',
                    max_retries INTEGER DEFAULT 3,
                    timeout_seconds INTEGER,
                    tags TEXT DEFAULT '[]',
                    metadata TEXT DEFAULT '{}',
                    status TEXT DEFAULT 'PENDING',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    last_run TEXT,
                    next_run TEXT,
                    run_count INTEGER DEFAULT 0,
                    fail_count INTEGER DEFAULT 0,
                    error_log TEXT DEFAULT '[]'
                )
            """)

            # File operations table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS file_operations (
                    id TEXT PRIMARY KEY,
                    source TEXT NOT NULL,
                    destination TEXT,
                    operation TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',
                    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                    size_bytes INTEGER DEFAULT 0,
                    checksum TEXT,
                    error TEXT
                )
            """)

            # File index table (for duplicate detection)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS file_index (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE NOT NULL,
                    checksum TEXT NOT NULL,
                    size_bytes INTEGER,
                    modified_time TEXT,
                    indexed_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Create indexes for performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_next_run ON tasks(next_run)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_file_checksum ON file_index(checksum)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_file_ops_timestamp ON file_operations(timestamp)")

    # Task operations
    def save_task(self, task: Task) -> None:
        """Save or update a task."""
        with self._connection() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO tasks (
                    id, name, schedule_time, recurrence, interval_minutes,
                    priority, dependencies, max_retries, timeout_seconds,
                    tags, metadata, status, created_at, last_run, next_run,
                    run_count, fail_count, error_log
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                task.id, task.name, task.schedule_time.isoformat(),
                task.recurrence.value, task.interval_minutes, task.priority.value,
                json.dumps(task.dependencies), task.max_retries, task.timeout_seconds,
                json.dumps(list(task.tags)), json.dumps(task.metadata),
                task.status.name, task.created_at.isoformat(),
                task.last_run.isoformat() if task.last_run else None,
                task.next_run.isoformat() if task.next_run else None,
                task.run_count, task.fail_count, json.dumps(task.error_log)
            ))

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a task by ID."""
        with self._connection() as conn:
            cursor = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_pending_tasks(self) -> List[Dict[str, Any]]:
        """Get all pending tasks ordered by priority and schedule time."""
        with self._connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM tasks 
                WHERE status IN ('PENDING', 'PAUSED')
                ORDER BY priority DESC, schedule_time ASC
            """)
            return [dict(row) for row in cursor.fetchall()]

    def get_due_tasks(self, before: datetime) -> List[Dict[str, Any]]:
        """Get tasks that are due to run."""
        with self._connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM tasks 
                WHERE status = 'PENDING' 
                AND schedule_time <= ?
                ORDER BY priority DESC, schedule_time ASC
            """, (before.isoformat(),))
            return [dict(row) for row in cursor.fetchall()]

    def update_task_status(self, task_id: str, status: TaskStatus, 
                          error: Optional[str] = None) -> None:
        """Update task status and optionally append error."""
        with self._connection() as conn:
            if error:
                # Append error to log
                cursor = conn.execute("SELECT error_log FROM tasks WHERE id = ?", (task_id,))
                row = cursor.fetchone()
                errors = json.loads(row["error_log"]) if row else []
                errors.append(f"{datetime.now().isoformat()}: {error}")
                conn.execute(
                    "UPDATE tasks SET status = ?, error_log = ? WHERE id = ?",
                    (status.name, json.dumps(errors[-10:]), task_id)  # Keep last 10
                )
            else:
                conn.execute(
                    "UPDATE tasks SET status = ? WHERE id = ?",
                    (status.name, task_id)
                )

    def delete_task(self, task_id: str) -> None:
        """Delete a task."""
        with self._connection() as conn:
            conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))

    def get_all_tasks(self) -> List[Dict[str, Any]]:
        """Get all tasks."""
        with self._connection() as conn:
            cursor = conn.execute("SELECT * FROM tasks ORDER BY created_at DESC")
            return [dict(row) for row in cursor.fetchall()]

    # File operations
    def log_file_operation(self, op: FileOperation) -> None:
        """Log a file operation."""
        with self._connection() as conn:
            conn.execute("""
                INSERT INTO file_operations 
                (id, source, destination, operation, status, timestamp, size_bytes, checksum, error)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                op.id, str(op.source), str(op.destination) if op.destination else None,
                op.operation, op.status, op.timestamp.isoformat(),
                op.size_bytes, op.checksum, op.error
            ))

    def get_file_operations(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent file operations."""
        with self._connection() as conn:
            cursor = conn.execute("""
                SELECT * FROM file_operations 
                ORDER BY timestamp DESC 
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]

    # File index for duplicate detection
    def index_file(self, path: Path, checksum: str, size: int) -> None:
        """Add file to index."""
        with self._connection() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO file_index 
                (path, checksum, size_bytes, modified_time)
                VALUES (?, ?, ?, ?)
            """, (str(path), checksum, size, datetime.now().isoformat()))

    def find_duplicates(self) -> List[Dict[str, Any]]:
        """Find files with duplicate checksums."""
        with self._connection() as conn:
            cursor = conn.execute("""
                SELECT checksum, path, size_bytes, COUNT(*) as count
                FROM file_index
                GROUP BY checksum
                HAVING count > 1
                ORDER BY size_bytes DESC
            """)
            return [dict(row) for row in cursor.fetchall()]

    def get_stats(self) -> Dict[str, int]:
        """Get database statistics."""
        with self._connection() as conn:
            stats = {}
            cursor = conn.execute("SELECT COUNT(*) as count FROM tasks")
            stats["total_tasks"] = cursor.fetchone()["count"]

            cursor = conn.execute("SELECT COUNT(*) as count FROM tasks WHERE status = 'PENDING'")
            stats["pending_tasks"] = cursor.fetchone()["count"]

            cursor = conn.execute("SELECT COUNT(*) as count FROM tasks WHERE status = 'COMPLETED'")
            stats["completed_tasks"] = cursor.fetchone()["count"]

            cursor = conn.execute("SELECT COUNT(*) as count FROM tasks WHERE status = 'FAILED'")
            stats["failed_tasks"] = cursor.fetchone()["count"]

            cursor = conn.execute("SELECT COUNT(*) as count FROM file_operations")
            stats["file_operations"] = cursor.fetchone()["count"]

            cursor = conn.execute("SELECT COUNT(*) as count FROM file_index")
            stats["indexed_files"] = cursor.fetchone()["count"]

            return stats
