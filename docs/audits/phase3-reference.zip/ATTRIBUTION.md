# Attribution and component history

The input was a local TaskMaster v2.0 snapshot. No upstream URL, revision, Git
history, actual LICENSE file, or copyright notice was supplied. The original
READMEs described MIT and setup metadata named a placeholder author. These are
recorded observations, not verified permission or an invented attribution.

The original 11 Python files, two READMEs, and pre-implementation development
plan are preserved in `docs/audits/phase1-reference.zip`. Original source hashes
are recorded in `docs/audits/phase0-results.json`. The original files in that
archive must remain available as provenance evidence until a verified upstream
history and notices can be established. No Git history was created in this phase.

| Component | Origin and Phase 1 treatment |
| --- | --- |
| Models | Inherited task/rule types retained; Phase 2 adds immutable plan/source-state records and independent filesystem/history outcome fields |
| Database | Inherited persistence retained; Phase 2 adds backward-compatible file-outcome columns; scheduling defects remain |
| Scheduler | Inherited, unchanged; known defects remain |
| Organizer | Adapted: source/action validation, complete hashing, read-only reporting, shared plan/preview/apply adapters, conflict preservation, worker cleanup |
| Planning, execution, errors | Newly added in Phase 2 for root/template/state validation, confirmation, execution, and partial-failure reporting |
| CLI and module entry point | Adapted: syntax, dispatch, error exits, lazy resources, default preview, explicit destination/apply/approval, safety restrictions, accurate warnings |
| Plugin classes and manager | Inherited code consolidated from `plugins.py` into `plugins/__init__.py`; discovery default adjusted for that location |
| Demo | Replaced with a disposable preview/report example |
| Nested packaging and duplicated docs | Replaced by root `pyproject.toml` and authoritative README; nested README redirects |
| Regression tests and phase records | Newly added for this implementation |

The pre-Phase-2 state is separately preserved in
`docs/audits/phase2-reference.zip`. Phase 0/1 reports describe their historical
snapshots; current behavior is documented in the root README and Phase 2 record.

The inherited project is not represented as wholly original work. Resolve the
upstream reuse terms and preserve required copyright/license notices before
publishing retained or adapted code. No license identifier or author is invented
in the new package metadata.
