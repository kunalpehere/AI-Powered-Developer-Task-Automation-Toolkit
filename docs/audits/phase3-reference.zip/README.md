# TaskMaster — Phase 2

A Python CLI with an explicit plan → preview → apply contract for file
organization and full-content duplicate reporting. Developer-project inspection
and JSON workflows remain later phases. This is a development baseline.

## Install and verify

Python 3.12+ is required; validation uses Python 3.12.4 on Windows. From the
repository root (the directory containing `pyproject.toml`):

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m taskmaster --help
.\.venv\Scripts\taskmaster.exe --help
.\.venv\Scripts\tm.exe --help
.\.venv\Scripts\python.exe -m taskmaster.demo --directory .
```

On Linux/macOS use `.venv/bin/python`, `.venv/bin/taskmaster`, and `.venv/bin/tm`.
Those platforms are not yet validated. Rich is the only runtime dependency;
`[dev]` adds pytest. No API keys, service, Pillow, or PDF package is required.
Dependency ranges are declared, but a reproducible lock and vulnerability audit
remain release work. On managed Windows hosts, TEMP/TMP may need to point to an
existing writable directory for venv/pip operations.

## Preview and apply

Choose a folder containing only the artifacts you intend to organize. The current
scanner is recursive and still applies its default type rule to unmatched files;
do not point it at an entire source project. Source and destination roots must be
separate: neither may contain the other.

```powershell
# Default: inspect the plan without changing files, creating output directories,
# creating a database, writing history, or updating an index.
.\.venv\Scripts\taskmaster.exe organize --source .\sample-artifacts --destination .\organized

# Apply the displayed plan. Moves require explicit approval.
.\.venv\Scripts\taskmaster.exe organize --source .\sample-artifacts --destination .\organized --apply --yes

# Copies preserve sources and do not require destructive-operation approval.
.\.venv\Scripts\taskmaster.exe organize --source .\sample-artifacts --destination .\organized --action copy --apply

# Explicit conflict policy: error (default) or skip; replacement is unsupported.
.\.venv\Scripts\taskmaster.exe organize --source .\sample-artifacts --destination .\organized --conflict skip

.\.venv\Scripts\taskmaster.exe duplicates --dir .\sample-artifacts
```

`--dry-run` explicitly selects the same preview mode. It cannot be combined with
`--apply`. `--yes` requires `--apply`. When applying moves in an interactive
terminal, omitting `--yes` prompts after displaying the plan. A noninteractive
caller must supply `--yes`; refusal/absent approval changes no files or history.
The interactive organization wizard also previews a captured plan and requires
approval before applying it. An independently rerun CLI command builds a new plan;
the Python API below retains an exact plan between preview and apply. Plans are
not yet saved/loaded from disk.

Strategies are `type` (default) and `date` (current date, not modification date).
Size sorting returns an actionable error until Phase 3. `--template` overrides
the strategy template, for example `logs/{year}/{month}/{filename}`. Supported
placeholders are `{filename}`, `{name}` (stem), `{ext}`, `{type}`, `{mime}`,
`{date}`, `{year}`, `{month}`, and `{day}`. Unknown placeholders, attribute/index
lookups, conversions, format specifications, traversal, and nonportable destination
components are rejected. `{filename}` preserves extensionless names. Templates
are relative to the destination root; the Python API also accepts absolute paths
strictly inside that root.

Duplicate reporting hashes complete files with SHA-256, including legacy Python
`fast_mode=True` calls. It is read-only by default. Read errors fail the scan
rather than silently return a complete-looking report. Automatic duplicate
removal remains disabled: `duplicates --delete` exits 2 and deletes nothing.
Size-group optimization and project exclusions belong to Phase 3.

## Python planning API

```python
from pathlib import Path
from taskmaster.models import FileRule
from taskmaster.organizer import FileOrganizer

organizer = FileOrganizer()  # No database initialized.
try:
    organizer.add_rule(FileRule("logs", "*.log", "logs/{filename}", action="move"))
    plan = organizer.plan_directory(Path("sample-artifacts"), Path("organized"))
    preview = organizer.preview(plan)
    for item in preview:
        print(item.source, item.destination, item.status, item.error)
    # Call only after the caller has explicitly approved these operations.
    results = organizer.apply(plan, confirmed=True)
finally:
    organizer.close()
```

Plans and their operations/source fingerprints are frozen dataclasses. They
capture absolute roots, source identity and metadata, full SHA-256, final
paths/actions, conflicts, skips, and validation failures. Invalid entries are
reported alongside valid ones; each item is attempted once, with no automatic
retry or rollback. Rules/conditions are evaluated during planning; trusted Python
conditions must be read-only. Changing rules or adding files afterward does not
change an existing plan.

The retained `organize_file` and `organize_directory` adapters now require
`destination_root=...`; destructive execution requires `confirmed=True`.
`dry_run=True` uses the same preview contract. Rename/delete actions are available
only through explicit Python rules and require approval; automatic duplicate
deletion is unavailable. Every plan, including a delete plan, requires separate
source/destination roots. Legacy unplanned empty-directory cleanup and scheduled
file organization are explicitly disabled rather than bypassing this contract.

## Results, history, and guarantees

Apply revalidates roots, paths, identity/size/timestamps, and full content before
changes. Copying uses exclusive destination creation and verifies contents before
removing a moved source. Existing destination files/directories are preserved;
conflicts never grant overwrite permission. Repeated destinations or sources
within a plan are rejected. Filesystem/home roots, overlapping roots, symlinks,
junctions, and reparse-point components are rejected. On Windows, actual junction
checks were validated outside the sandbox; real file-symlink tests may skip when
the required privilege is absent.

The CLI records apply attempts in `taskmaster.db` in its working directory. The
Python API records history only when supplied a Database or history callback.
Preview and duplicate reports leave even existing history/index data unchanged.
Explicit legacy indexing is possible only with `record_index=True` and an
explicit Database; it is separate from read-only reporting. Organization no
longer updates the duplicate index as a hidden post-file step.

Each result separates `filesystem_status`, `destination_created`, `source_removed`,
`history_status`, and `history_error` from the overall `status` and file error.
A successful file change followed by a history failure is `completed_with_errors`,
not a claim that the file was unchanged. A write/metadata failure can leave a new
partial file; a failed source unlink can leave a complete destination and source.
Results report these facts, and the batch continues. Inspect those paths before
retrying. New partial files and newly created parent directories are not rolled
back. Existing history databases receive additive outcome columns without losing
old rows; historical outcomes that were never captured remain `unknown`.

Success/preview uses exit 0; per-file or history failures use 1; invalid CLI
arguments use 2. Skip is a reported nonfailure. Summary success counts include
completed file changes with history failures; a separate history-failure count
and exit 1 expose the persistence problem.

Path/identity checks are practical safeguards, not an OS security sandbox. Another
process can still change a path between checking and opening/unlinking it. Do not
apply plans in actively modified or untrusted trees. Reading files may update OS
access times; preview makes no intentional content, directory, or persistence
writes. Move/rename use copy-plus-unlink and do not guarantee atomicity or full
ACL/alternate-stream preservation. Filesystem and SQLite transactions are not a
single atomic unit, and no exactly-once/crash-recovery guarantee is made.

## Deferred features and provenance

Experimental task add/list/start and the menu remain available. Scheduler command
restoration, due times, retries, dependencies, timeouts, failure logs, and shutdown
remain unreliable/unverified. Registration is tested; reliable scheduling is not.
Interactive Python evaluation remains disabled. Shell tasks raise on nonzero exit.

`from taskmaster.plugins import PluginManager` works; explicit registration is
tested. Dynamic discovery and image/PDF processing are deferred; imported plugins
execute Python and must be trusted. JSON workflows, structured run history,
project inspection, release CI, dependency audit, and upstream license verification
are not part of Phase 2.

See the [development plan](DEVELOPMENT_PLAN.md), [Phase 2 record](docs/PHASE_2.md),
[Phase 1 record](docs/PHASE_1.md), and [Phase 0 audit](docs/audits/PHASE_0_AUDIT.md).
The pre-Phase-2 source/tests/docs are preserved in
[phase2-reference.zip](docs/audits/phase2-reference.zip); the original supplied
snapshot remains in [phase1-reference.zip](docs/audits/phase1-reference.zip).

This derives from the supplied TaskMaster snapshot. Its upstream URL/revision,
copyright holder, and actual license notices remain unresolved. The original
README said MIT but no LICENSE was supplied. No new author/license claim is made;
resolve provenance before distributing inherited code. See
[attribution](ATTRIBUTION.md).
