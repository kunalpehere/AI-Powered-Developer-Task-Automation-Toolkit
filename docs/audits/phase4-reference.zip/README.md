# TaskMaster — Developer Task Automation Toolkit

Inspect a developer workspace, report fully verified duplicate files, and
organize explicitly selected artifacts through plan → preview → apply → report.
Phase 3 delivers these three MVP workflows. JSON workflows and expanded execution
history belong to Phase 4; this is a development build, not a production release.

## Install and verify

Requires Python 3.12+. Run from the repository root containing `pyproject.toml`:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\taskmaster.exe --help
.\.venv\Scripts\python.exe -m taskmaster.demo --directory .
```

`tm` is an equivalent console entry point; `python -m taskmaster` also works.
On Linux/macOS use `.venv/bin/python`, `.venv/bin/taskmaster`, and `.venv/bin/tm`.
Validation currently covers Windows/Python 3.12.4. Rich is the only runtime
dependency; `[dev]` adds pytest. No service, API key, Pillow, or PDF package is
needed. Full dependency locking, vulnerability review, and cross-platform release
checks remain later work. Managed Windows hosts may need TEMP/TMP to point to an
existing writable directory for venv/pip.

The demo creates its own temporary child directory, inspects sample logs,
previews/applies disposable copies, reports duplicates, and removes its fixtures.
It never runs the scheduler, initializes SQLite, or modifies existing files.

## Inspect a workspace

```powershell
.\.venv\Scripts\tm.exe inspect --source . --top 10
.\.venv\Scripts\tm.exe inspect --source . --min-size 1048576 --exclude "build/" --format json
```

Reports file count, total bytes, final-extension counts/bytes, and the largest
files. Extensions are lowercased; extensionless files use an empty extension in
JSON and `(no extension)` in text. Largest files sort by descending bytes and then
root-relative path. `--top` defaults to 10; `--min-size` filters that listing, not
the totals. Both accept nonnegative integers, and `--top 0` omits the listing.

Inspection reads metadata, not file contents. Errors are visible: incomplete scans
return exit 1 and `complete: false`; counts cover successfully inspected files.

## Report duplicates

```powershell
.\.venv\Scripts\tm.exe duplicates --dir . --exclude "reports/private/"
.\.venv\Scripts\tm.exe duplicates --dir . --format json
```

Files are grouped by size first. Only sizes with multiple files receive a complete
SHA-256 hash, using bounded reads and sequential processing. Empty files are
supported. Every reported group includes all its verified members and their size.
Reports expose candidate/hashed counts so the size filter can be checked. Groups
sort by descending size and SHA-256; member paths are sorted. `redundant_bytes`
measures logical duplicate content, not guaranteed disk savings (hard links,
compression, and filesystem allocation can differ).

Metadata is checked around hashing to detect changed candidates. Read errors
produce an incomplete report and exit 1 while retaining other verified groups.
Unique-size files are not read for content, so their content-read permissions are
not tested. No scan is an atomic snapshot of a concurrently changing tree.

Duplicate reporting creates no database and changes no index. Automatic deletion
remains disabled; `duplicates --delete` exits 2 and deletes nothing.

## Organize selected artifacts

Directory organization requires a repeatable `--include` pattern or an explicit
`--all-files`. It never chooses the entire tree implicitly. Include logs, exported
reports, or build artifacts rather than selecting source files unintentionally.
Source and destination roots must be separate and nonoverlapping.

```powershell
# Preview selected logs inside a project; no filesystem/history writes.
.\.venv\Scripts\tm.exe organize --source . --destination ..\organized --include "logs/**/*.log"

# Apply that scope as moves with explicit approval.
.\.venv\Scripts\tm.exe organize --source . --destination ..\organized --include "logs/**/*.log" --apply --yes

# Select multiple artifact sets and copy them, preserving sources.
.\.venv\Scripts\tm.exe organize --source . --destination ..\exports --include "reports/**/*.csv" --include "reports/**/*.json" --action copy --apply --format json

# Size sorting of a deliberately selected artifact folder.
.\.venv\Scripts\tm.exe organize --source .\artifacts --destination ..\sorted-artifacts --all-files --strategy size
```

Preview is the default; `--dry-run` explicitly selects it. `--apply` performs the
captured plan. Moves need `--yes` in noninteractive or JSON mode; in a text
terminal the command can prompt after displaying the plan. Refusing approval
changes no files/history. Copies require `--apply` but not destructive approval.
`--yes` requires `--apply`; `--dry-run` and `--apply` are mutually exclusive.
An independently rerun CLI command builds a new plan. The Python API can retain
one exact plan between preview and apply; saved plan files are not implemented.

Strategies are `type`, `date`, and `size`. Date uses the date when planning, not
file modification dates. Size categories are **small < 1 MiB**, **medium from
1 MiB to less than 100 MiB**, and **large ≥ 100 MiB** (binary units). Default
strategies preserve root-relative subdirectories and complete filenames under
the selected category/date/size. For example, `logs/archive/app.log` becomes
`misc/logs/archive/app.log` under type sorting. Same-named files in separate
subdirectories remain separate by default.

`--template` overrides the strategy. Supported fields are `{filename}`, `{name}`
(stem), `{ext}`, `{type}`, `{mime}`, `{date}`, `{year}`, `{month}`, `{day}`,
`{size_category}`, and `{relative_dir}` (empty at the source root). Unknown fields,
attribute/index lookups, format specifications, conversions, traversal, reserved
names, and nonportable destination components are rejected. An explicit template
can flatten paths, but collisions fail rather than overwrite. `--conflict error`
is the default; `--conflict skip` reports conflicts without changing them.

## Scope and exclusions

All three commands share:

- `--exclude PATTERN`, repeatable; appended to the defaults.
- `--no-default-excludes`, to use only explicit exclusions.
- `--no-recursive`, to scan immediate files only.
- `--format text|json`, defaulting to readable text.

Default directory/file-name exclusions are `.git`, `.venv*`, `venv`,
`__pycache__`, `node_modules`, `.pytest_cache`, `.mypy_cache`, `.ruff_cache`, `.tox`,
and `.nox`. Excluded directories are pruned before access/link checks. Exclusion
counts represent encountered/pruned entries, not every descendant inside them.
Inspect/duplicates also accept optional repeated `--include` filters.

Patterns without a slash match a basename at any depth (`*.log`). Patterns with
slashes match from the scan root: `reports/*.csv` selects direct CSV children;
`reports/**/*.csv` includes direct and nested CSV files. `**` spans zero or more
directory segments; `*` within a path segment never crosses a slash. A trailing
slash means the subtree (`build/` means `build/**`). Backslashes are accepted as
separators. Matching is case-sensitive on all platforms. Absolute paths, empty
patterns, and traversal are invalid. Quote globs in the shell so TaskMaster
receives the pattern itself.

Inspection/duplicate scans report included links, reparse points, or unreadable
paths as errors. Organization refuses incomplete scans before making a plan for
execution. A selection matching no files after exclusions returns an actionable
error; an explicitly selected empty tree via `--all-files` is a valid empty plan.

## Python API

```python
from pathlib import Path
from taskmaster.inspection import inspect_project
from taskmaster.duplicates import duplicate_report
from taskmaster.models import FileRule
from taskmaster.organizer import FileOrganizer

print(inspect_project(Path("project"), exclusions=("build/",)))
print(duplicate_report(Path("project")))
organizer = FileOrganizer()  # No database initialized.
try:
    organizer.add_rule(FileRule("logs", "*.log", "logs/{relative_dir}/{filename}", action="move"))
    plan = organizer.plan_directory(Path("project"), Path("organized"), includes=("logs/**/*.log",))
    for item in organizer.preview(plan):
        print(item.source, item.destination, item.status, item.error)
    # Call only after the caller explicitly approves this captured plan.
    results = organizer.apply(plan, confirmed=True)
finally:
    organizer.close()
```

`plan_directory`/`organize_directory` require `includes=(...)` or `all_files=True`.
Exclusions are `exclusions=(...)` and `use_default_excludes=False` disables default
patterns. Rule patterns match basenames case-sensitively; selected files with no
enabled matching rule are skipped. The inherited fallback that moved unmatched
files is removed. Direct `organize_file` already selects one file explicitly and
still requires `destination_root=...`. Destructive adapters require
`confirmed=True`; `dry_run=True` uses the shared read-only preview.

The legacy `find_duplicates` dictionary API uses the same size-first/full-SHA
algorithm and raises on incomplete reports. `fast_mode=True` never enables
partial fingerprints. Explicit legacy indexing is possible only with
`record_index=True` and a supplied Database; ordinary reports never write it.

## Reports, history, and safety limits

JSON is one unwrapped document on stdout, with `schema_version: 1`, command,
completion status, scope, summaries, and command-specific details. Inspection and
duplicate reports are deterministic for an unchanged tree. Organization reports
include planned identity/content fingerprints, intended paths, and actual
filesystem/history outcomes, without random IDs or execution timestamps.
JSON application never prompts. Runtime errors after valid argument parsing also
produce JSON; invalid CLI syntax/required options use argparse's stderr usage
message and exit 2. Reports can be redirected by the caller; no report file is
created automatically. Readable CLI reports escape characters that the selected
terminal/pipe encoding cannot represent (for example Chinese paths in CP1252),
instead of crashing. JSON escapes remain lossless when parsed.

The CLI writes apply attempts to `taskmaster.db` in its working directory. That
file and its SQLite sidecars must be outside the selected sources and destination
root. A project root may contain history while includes select only logs/reports;
selecting the history file itself is rejected. The Python API records history
only when given a Database/history callback. Conditions and custom callbacks are
trusted Python and must keep their own side effects/storage appropriate.

Plans and source states are immutable. Apply rechecks roots, links, identity,
metadata, and full contents; creates destinations exclusively; verifies copies
before unlinking moved sources; and preserves existing destinations. Results
separate `filesystem_status`, `destination_created`, `source_removed`,
`history_status`, `history_error`, and overall status. A completed file change
with failed history is `completed_with_errors`; CLI exit 1 exposes the failure.
A failed unlink can leave source and complete destination; a failed write can
leave a partial destination. Inspect these before retrying. New partial files and
parent directories are not automatically rolled back. Batches continue after
per-file failures, with no automatic retries.

Success, preview, or an ordinary skip uses exit 0; access/validation/per-file or
history failures use 1. Argument syntax uses 2. Preview makes no intentional
filesystem/persistence writes, though reading may update OS access times.
Path checks are practical safeguards, not an OS security sandbox: another process
can still replace a path between validation and open/unlink. Avoid application
in hostile or actively modified trees. Move/rename are copy-plus-unlink, with no
atomicity/full ACL or alternate-stream preservation guarantee. Filesystem and
SQLite are separate transactions; crash recovery/exactly-once execution is not
claimed. Symlinks/junctions/reparse points, filesystem/home organization roots,
and overlapping roots are rejected. Real Windows junction tests pass; a real
file-symlink test skips when account privileges prevent creating its fixture.

## Deferred work and provenance

Experimental task add/list/start and the menu remain. Reliable scheduler command
restoration, due times, retries, dependencies, timeouts, error logs, and shutdown
remain unverified or defective. Scheduled file organization, interactive Python
evaluation, automatic duplicate deletion, and unplanned empty-directory cleanup
remain unavailable. Plugin imports/explicit registration work; dynamic discovery
and image/PDF processing are deferred. Plugins execute trusted Python.

Phase 4 covers validated JSON workflows and expanded history, not this phase's
JSON output reports. CI, release testing, dependency assurance, broader platform
coverage, and verified upstream attribution remain later work.
See [development plan](DEVELOPMENT_PLAN.md), [Phase 3 record](docs/PHASE_3.md),
[Phase 2 record](docs/PHASE_2.md), and [original audit](docs/audits/PHASE_0_AUDIT.md).
The pre-Phase-3 code/tests/docs are preserved in
[phase3-reference.zip](docs/audits/phase3-reference.zip); earlier archives/evidence
remain historical.

This derives from the supplied TaskMaster snapshot. Its upstream URL/revision,
copyright holder, and actual license notices are unresolved. The original README
said MIT but supplied no LICENSE. No new copyright/license claim is made; resolve
provenance before distributing inherited code. See [attribution](ATTRIBUTION.md).
