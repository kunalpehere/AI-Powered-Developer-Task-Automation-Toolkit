"""
TaskMaster - Async Task Scheduler Engine
Handles task execution, scheduling, and lifecycle management.
"""
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any
from concurrent.futures import ThreadPoolExecutor
import logging

from .models import Task, TaskStatus
from .database import Database

logger = logging.getLogger("TaskMaster")

class TaskScheduler:
    """Advanced async task scheduler with priority queue and dependency resolution."""

    def __init__(self, db: Database, max_workers: int = 4):
        self.db = db
        self.max_workers = max_workers
        self.tasks: Dict[str, Task] = {}
        self._running = False
        self._task_queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._lock = asyncio.Lock()
        self._watcher_task: Optional[asyncio.Task] = None
        self._workers: List[asyncio.Task] = []
        self._callbacks: Dict[str, List[Callable]] = {}

    def register_task(self, task: Task) -> str:
        """Register a new task and persist to database."""
        task.next_run = task.schedule_time
        self.tasks[task.id] = task
        self.db.save_task(task)

        # Register callbacks
        if task.id not in self._callbacks:
            self._callbacks[task.id] = []

        logger.info(f"Registered task: {task.name} (ID: {task.id})")
        return task.id

    def on_complete(self, task_id: str, callback: Callable) -> None:
        """Register a callback for task completion."""
        if task_id not in self._callbacks:
            self._callbacks[task_id] = []
        self._callbacks[task_id].append(callback)

    def _check_dependencies(self, task: Task) -> bool:
        """Check if all dependencies are completed."""
        for dep_id in task.dependencies:
            dep_task = self.tasks.get(dep_id)
            if not dep_task:
                # Check database
                dep_data = self.db.get_task(dep_id)
                if not dep_data or dep_data["status"] != "COMPLETED":
                    return False
            elif dep_task.status != TaskStatus.COMPLETED:
                return False
        return True

    async def _execute_task(self, task: Task) -> Any:
        """Execute a single task with timeout and retry logic."""
        async with self._lock:
            task.status = TaskStatus.RUNNING
            task.last_run = datetime.now()
            task.run_count += 1
            self.db.save_task(task)

        try:
            # Check dependencies first
            if not self._check_dependencies(task):
                raise Exception("Dependencies not satisfied")

            # Execute with timeout
            if task.timeout_seconds:
                result = await asyncio.wait_for(
                    self._run_command(task.command),
                    timeout=task.timeout_seconds
                )
            else:
                result = await self._run_command(task.command)

            # Success
            async with self._lock:
                task.status = TaskStatus.COMPLETED
                task.next_run = task.calculate_next_run()
                if task.next_run:
                    task.status = TaskStatus.PENDING  # Reset for next run
                self.db.save_task(task)

            # Trigger callbacks
            for callback in self._callbacks.get(task.id, []):
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(task, result)
                    else:
                        callback(task, result)
                except Exception as e:
                    logger.error(f"Callback error for task {task.id}: {e}")

            logger.info(f"Task completed: {task.name} (ID: {task.id})")
            return result

        except asyncio.TimeoutError:
            error_msg = f"Task timed out after {task.timeout_seconds}s"
            await self._handle_failure(task, error_msg)
            raise TimeoutError(error_msg)

        except Exception as e:
            error_msg = str(e)
            await self._handle_failure(task, error_msg)
            raise

    async def _run_command(self, command: Callable) -> Any:
        """Run a command, handling both sync and async functions."""
        if asyncio.iscoroutinefunction(command):
            return await command()
        else:
            # Run sync function in thread pool
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(self._executor, command)

    async def _handle_failure(self, task: Task, error: str) -> None:
        """Handle task failure with retry logic."""
        task.fail_count += 1

        if task.fail_count < task.max_retries:
            # Retry with exponential backoff
            backoff = min(2 ** task.fail_count, 300)  # Max 5 minutes
            task.next_run = datetime.now() + timedelta(seconds=backoff)
            task.status = TaskStatus.PENDING
            logger.warning(f"Task {task.id} failed (attempt {task.fail_count}), retrying in {backoff}s")
        else:
            task.status = TaskStatus.FAILED
            logger.error(f"Task {task.id} failed permanently after {task.max_retries} retries")

        self.db.update_task_status(task.id, task.status, error)
        self.db.save_task(task)

    async def _watcher(self) -> None:
        """Background watcher that queues due tasks."""
        while self._running:
            try:
                now = datetime.now()
                due_tasks = self.db.get_due_tasks(now)

                for task_data in due_tasks:
                    task_id = task_data["id"]
                    if task_id in self.tasks and self.tasks[task_id].status == TaskStatus.PENDING:
                        task = self.tasks[task_id]
                        # Priority: lower number = higher priority (PriorityQueue behavior)
                        priority_value = -task.priority.value
                        await self._task_queue.put((priority_value, task_id))

                await asyncio.sleep(1)  # Check every second
            except Exception as e:
                logger.error(f"Watcher error: {e}")
                await asyncio.sleep(5)

    async def _worker(self) -> None:
        """Worker that processes tasks from the queue."""
        while self._running:
            try:
                # Wait for a task with timeout
                try:
                    priority, task_id = await asyncio.wait_for(
                        self._task_queue.get(), timeout=1.0
                    )
                except asyncio.TimeoutError:
                    continue

                task = self.tasks.get(task_id)
                if not task or task.status != TaskStatus.PENDING:
                    continue

                # Execute the task
                try:
                    await self._execute_task(task)
                except Exception as e:
                    logger.error(f"Task execution error: {e}")
                finally:
                    self._task_queue.task_done()

            except Exception as e:
                logger.error(f"Worker error: {e}")
                await asyncio.sleep(1)

    async def start(self) -> None:
        """Start the scheduler."""
        if self._running:
            return

        self._running = True

        # Load existing tasks from database
        for task_data in self.db.get_pending_tasks():
            # Tasks loaded from DB need to be re-registered with their commands
            # This is handled by the CLI layer
            pass

        # Start watcher
        self._watcher_task = asyncio.create_task(self._watcher())

        # Start workers
        for i in range(self.max_workers):
            worker = asyncio.create_task(self._worker())
            self._workers.append(worker)

        logger.info(f"Scheduler started with {self.max_workers} workers")

    async def stop(self) -> None:
        """Gracefully stop the scheduler."""
        self._running = False

        if self._watcher_task:
            self._watcher_task.cancel()
            try:
                await self._watcher_task
            except asyncio.CancelledError:
                pass

        for worker in self._workers:
            worker.cancel()
            try:
                await worker
            except asyncio.CancelledError:
                pass

        self._workers.clear()
        self._executor.shutdown(wait=True)
        logger.info("Scheduler stopped")

    def cancel_task(self, task_id: str) -> bool:
        """Cancel a pending task."""
        if task_id in self.tasks:
            task = self.tasks[task_id]
            if task.status == TaskStatus.PENDING:
                task.status = TaskStatus.CANCELLED
                self.db.update_task_status(task_id, TaskStatus.CANCELLED)
                return True
        return False

    def pause_task(self, task_id: str) -> bool:
        """Pause a task."""
        if task_id in self.tasks:
            task = self.tasks[task_id]
            task.status = TaskStatus.PAUSED
            self.db.update_task_status(task_id, TaskStatus.PAUSED)
            return True
        return False

    def resume_task(self, task_id: str) -> bool:
        """Resume a paused task."""
        if task_id in self.tasks:
            task = self.tasks[task_id]
            task.status = TaskStatus.PENDING
            task.next_run = datetime.now()
            self.db.update_task_status(task_id, TaskStatus.PENDING)
            return True
        return False

    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed status of a task."""
        task = self.tasks.get(task_id)
        if task:
            return task.to_dict()
        return self.db.get_task(task_id)
